import { Component } from '@angular/core';

@Component({
  selector: 'app-seller-auth',
  standalone: true,
  imports: [],
  templateUrl: './seller-auth.component.html',
  styleUrl: './seller-auth.component.css'
})
export class SellerAuthComponent {

}
